/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 14, 2022, 3:46 PM
 */

#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!

    const float litersPerGallon=0.264179;       //globally defined constant
    


float calcMPG(float litersOfGas, float milesTraveled) {                   //function to calculate miles per gallon
    float milesPerGallon;
    
    milesPerGallon=(milesTraveled)/(litersPerGallon*litersOfGas);
    
    return milesPerGallon;

    
};

float calcMPG2(float litersOfGas2, float milesTraveled2) {                   //function to calculate miles per gallon
    float milesPerGallon2;
    
    milesPerGallon2=(milesTraveled2)/(litersPerGallon*litersOfGas2);
    
    return milesPerGallon2;

    
};

int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float litersOfGas;
    float milesTraveled;
    float MPG;
    float litersOfGas2;
    float milesTraveled2;
    float MPG2;
    string yORn="y";
    
    //Initialize or input i.e. set variable values
       //asks user if they want to make calculation again
    
                   //for loop to call function and preform calculation
   
    while (yORn=="y") {
    cout<<"Car 1"<<endl;
    cout<<"Enter number of liters of gasoline:";      
    cin>>litersOfGas;
    cout<<endl;
    
    cout<<"Enter number of miles traveled:";
    cin>>milesTraveled;
    cout<<endl;

    MPG=calcMPG(litersOfGas, milesTraveled);
    cout<<"miles per gallon:"<<" "<<fixed<<setprecision(2)<<MPG<<endl;
    cout<<endl;
    
    cout<<"Car 2"<<endl;
    cout<<"Enter number of liters of gasoline:";      
    cin>>litersOfGas2;
    cout<<endl;
    
    cout<<"Enter number of miles traveled:";
    cin>>milesTraveled2;
    cout<<endl;

    

    MPG2=calcMPG2(litersOfGas2, milesTraveled2);
    cout<<"miles per gallon:"<<" "<<fixed<<setprecision(2)<<MPG2<<endl;
    cout<<endl;
    
    if (MPG>MPG2){
        cout<<"Car 1 is more fuel efficient"<<endl;
        cout<<endl;
    } else if (MPG<MPG2){
        cout<<"Car 2 is more fuel efficient"<<endl;
        cout<<endl;
    }
    
    cout<<"Again:"<<endl;
    cin>>yORn;
        if (yORn=="y"){
            cout<<endl;
        }
            
    }
    
                                       //print out end line if the user is done 
        

    
    
    return 0;   
}
