/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 25, 2022, 6:06 PM
 */

#include <iostream>  //Input/Output Library
#include <cstdlib>   //Srand
#include <ctime>     //Time to set random number seed
#include <cmath>     //Math Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
void  init(float test[],int SIZE){ //take in the array
    for(int i=0;i<SIZE;i++){
        cin>>test[i];
    }
};

float avgX(float a[],int n){ //Calculate the average
    float avgArray, sum=0;
    for(int i=0;i<n;i++){
        sum+=a[i];
    }
    avgArray=sum/n;
    return avgArray;
};

float stdX(float test[],int SIZE){ //calulate SD
    float SD=0;
    int p;
    for(int i=0;i<SIZE;i++){
        SD+=pow((test[i]-avgX(test,SIZE)),2);
    }
    p=SIZE-1;
    return sqrt(SD/p);
};

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    const int SIZE=20;
    float test[SIZE];
    
    //take in the array
    init(test,SIZE);

    //Display the outputs
    cout<<"The average            = "<<fixed<<setprecision(7)<<avgX(test,SIZE)<<endl;
    cout<<"The standard deviation = "<<fixed<<setprecision(7)<<stdX(test,SIZE)<<endl;

    //Exit stage right or left!
    return 0;
}

