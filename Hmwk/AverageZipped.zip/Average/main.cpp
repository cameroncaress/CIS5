/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 9:15 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

     //Set the random number seed
    
    //Declare Variables
    float score1, score2, score3, score4, score5, averagescore;
    
    //Initialize or input i.e. set variable values
    cout<<"Input 5 numbers to average."<<endl;
    cin>>score1>>score2>>score3>>score4>>score5;
    
    //Map inputs -> outputs
    averagescore=(score1+score2+score3+score4+score5)/5.0;
    
    //Display the outputs
    cout<<"The average ="<<" "<<fixed<<setprecision(1)<<averagescore;
    
    //Exit stage right or left!
    
    return 0;
}

