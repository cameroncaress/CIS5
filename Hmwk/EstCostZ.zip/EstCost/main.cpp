/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 14, 2022, 3:48 PM
 */

#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
float calcInflation(float currentPrice, float pastPrice){
    float percInflation;
    
    percInflation=((currentPrice-pastPrice)/pastPrice)*100.00;
    
    return percInflation;
};

float expectedPrice(float infRate, float currentPrice){
    float price1Year;
    
    price1Year=(currentPrice*infRate/100.00)+currentPrice;
    
    return price1Year;
};

float expectedPrice2(float infRate, float price1Year){
    float price2Year;
    
    price2Year=(price1Year*infRate/100.00)+price1Year;
    
    return price2Year;
};



//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float currentPrice;
    float pastPrice;
    float infRate;
    float price1Year;
    float price2Year;
    string yORn="y";
    
    
    //Initialize or input i.e. set variable values
    while (yORn=="y") {
        cout<<"Enter current price:"<<endl;
        cin>>currentPrice;
        cout<<"Enter year-ago price:"<<endl;
        cin>>pastPrice;
        infRate=calcInflation(currentPrice, pastPrice);
        cout<<"Inflation rate:"<<" "<<fixed<<setprecision(2)<<infRate<<"%"<<endl;
        cout<<endl;
        price1Year=expectedPrice(infRate, currentPrice);
        cout<<"Price in one year:"<<" "<<"$"<<fixed<<setprecision(2)<<price1Year<<endl;
        price2Year=expectedPrice2(infRate, price1Year);
        cout<<"Price in two year:"<<" "<<"$"<<fixed<<setprecision(2)<<price2Year<<endl;
        cout<<endl;
        cout<<"Again:"<<endl;

        cin>>yORn;
        if (yORn=="y"){
            cout<<endl;
        }
        
    }
    
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}
