/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 9:45 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

     //Set the random number seed
    
    //Declare Variables
    
    float weight;
    int maxCans;
    float artSwet=0.001;
    float maxSwet;
    float gramCan;
    
    //Initialize or input i.e. set variable values
    
    cout<<"Program to calculate the limit of Soda Pop Consumption."<<endl;
    cout<<"Input the desired dieters weight in lbs."<<endl;
    cin>>weight;
   
    //Map inputs -> outputs
    
    maxSwet=(453.592*weight)/7.0;
    gramCan=artSwet*350.0;
    maxCans=maxSwet/gramCan;
    
    //Display the outputs
    
    cout<<"The maximum number of soda pop cans"<<endl;
    cout<<"which can be consumed is"<<" "<<maxCans<<" "<<"cans";

    //Exit stage right or left!
    
    return 0;
}

