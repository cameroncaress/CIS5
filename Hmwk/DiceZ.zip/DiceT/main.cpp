/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 25, 2022, 6:03 PM
 */
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const int COLS=6;

//Execution Begins Here!
int main(int argc, char** argv) {
    int rows, cols, num, outnum;
    
    cout<<"Think of this as the Sum of Dice Table"<<endl;
    cout<<"           C o l u m n s"<<endl;
    cout<<"     |   1   2   3   4   5   6"<<endl;
    cout<<"----------------------------------"<<endl;
    
    cin>>num;
    for(rows=1;rows<=num;rows++){
        for(cols=1;cols<=num;cols++){
            outnum=rows+cols;
            if(rows==cols){
                cout<<setw(4)<<setfill(' ')<<outnum;
            }else if(rows!=cols){
                cout<<setw(4)<<setfill(' ')<<outnum;
            }
        }
        cout<<endl;
    }
    //Exit stage right or left!
    return 0;
}
