/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 9:19 AM
 */

#include <cstdlib>
#include <iomanip>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

     //Set the random number seed
    
    //Declare Variables
    float numberofcookies;
    float caloriesconsumed;
    
    //Initialize or input i.e. set variable values
    cout<<"Calorie Counter"<<endl;
    cout<<"How many cookies did you eat?"<<endl;
    cin>>numberofcookies;
    
    //Map inputs -> outputs
    caloriesconsumed=numberofcookies*75;
    
    //Display the outputs
    cout<<"You consumed"<<" "<<caloriesconsumed<<" "<<"calories.";
    
    //Exit stage right or left!
    
    return 0;
}

