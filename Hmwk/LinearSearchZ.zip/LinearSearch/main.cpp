/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 25, 2022, 6:10 PM
 */

#include <iostream>  //Input/Output Library
#include <iomanip>
#include <cstdlib>   //Random Functions
#include <ctime>     //Time Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
int fillAry(int a[],int SIZE){
    for(int i=0;i<=SIZE;i++){
        cin>>a[i];
    }
    return a[SIZE];
};

void prntAry(int a[],int n,int val){
    
};

int linSrch(int a[],int n,int val){
    for(int i=0;i<n;i++){
        if(a[i]==val){
            return i;
        }
    }    
    return -1;

}

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed

    //Declare Variables
    const int SIZE=100;
    int array[SIZE];
    int indx,val;
    
    //Initialize or input i.e. set variable values
    val=50;
    array[SIZE]=fillAry(array,SIZE);
    indx=linSrch(array,SIZE,val);
    
    //Display the outputs
    if(indx>=0){
        cout<<val<<" was found at indx = "<<linSrch(array,SIZE,val)<<endl;
    }else{
        cout<<val<<" was found at ";
    }
    //Exit stage right or left!
    return 0;
}
