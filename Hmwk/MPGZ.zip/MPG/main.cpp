/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 14, 2022, 3:45 PM
 */

#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!

    const float litersPerGallon=0.264179;       //globally defined constant
    


float calcMPG(float litersOfGas, float milesTraveled) {                   //function to calculate miles per gallon
    float milesPerGallon;
    
    milesPerGallon=(milesTraveled)/(litersPerGallon*litersOfGas);
    
    return milesPerGallon;

    
};

int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float litersOfGas;
    float milesTraveled;
    float MPG;
    string yORn="y";
    
    //Initialize or input i.e. set variable values
       //asks user if they want to make calculation again
    
                   //for loop to call function and preform calculation
   
    while (yORn=="y") {
    cout<<"Enter number of liters of gasoline:"<<endl;      
    cin>>litersOfGas;
    cout<<endl;
    
    cout<<"Enter number of miles traveled:"<<endl;
    cin>>milesTraveled;
    cout<<endl;

    MPG=calcMPG(litersOfGas, milesTraveled);
    cout<<"miles per gallon:"<<endl;
    cout<<fixed<<setprecision(2)<<MPG<<endl;
    cout<<"Again:"<<endl;
    cin>>yORn;
        if (yORn=="y"){
            cout<<endl;
        }
            
    }
    
                                       //print out end line if the user is done 
        

    
    
    return 0;   
}
    
