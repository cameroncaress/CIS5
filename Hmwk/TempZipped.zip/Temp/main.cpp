/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 9:26 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    //Set the random number seed
    
    //Declare Variables
    float tempF;
    float tempC;
    
    //Initialize or input i.e. set variable values
    cout<<"Temperature Converter"<<endl;
    cout<<"Input Degrees Fahrenheit"<<endl;
    cin>>tempF;
    
    //Map inputs -> outputs
    tempC=(5.0*(tempF-32.0))/9.0;
    
    //Display the outputs
    cout<<fixed<<setprecision(1)<<tempF<<" "<<"Degrees Fahrenheit"<<" "<<"="<<" "<<fixed<<setprecision(1)<<tempC<<" "<<"Degrees Centigrade";
    //Exit stage right or left!
    
    return 0;
}

