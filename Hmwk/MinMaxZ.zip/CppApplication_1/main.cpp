/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 21, 2022, 5:14 PM
 */

#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
void minmax(int,int,int,int&,int&);//Function to find the min and max

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int firstN, secondN, thirdN;
    int min, max;
    
    //Initialize Variables
    cout<<"Input 3 numbers"<<endl;
    cin>>firstN>>secondN>>thirdN;
    //Process/Map inputs to outputs
    
    if (firstN>=secondN && firstN>=thirdN && secondN<=thirdN){
        max=firstN;
        min=secondN;
    } else if (firstN>=secondN && firstN>=thirdN && thirdN<=secondN){
        max=firstN;
        min=thirdN;
    } else if (thirdN>=firstN && thirdN>=secondN && firstN<=secondN){
        max=thirdN;
        min=firstN;
    } else if (thirdN>=firstN && thirdN>=secondN && secondN<=firstN){
        max=thirdN;
        min=secondN;
    } else if (secondN>=firstN && secondN>=thirdN && firstN<=thirdN){
        max=secondN;
        min=firstN;
    } else if (secondN>=firstN && secondN>=thirdN && thirdN<=firstN){
        max=secondN;
        min=thirdN;
    }
        
    
    //Output data
    
    cout<<"Min"<<" "<<"="<<" "<<min<<endl;
    cout<<"Max"<<" "<<"="<<" "<<max;

    
    //Exit stage right!
    return 0;
}
