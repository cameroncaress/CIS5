/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 14, 2022, 3:40 PM
 */

#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int inputNum=1;
    int lowNum=1000;
    int upperNum=-100000;
    
    //Initialize or input i.e. set variable values
    while (inputNum!=-99){
        cin>>inputNum;
    
        if (inputNum>= upperNum && inputNum!=-99){
                upperNum=inputNum;
        };
        
        if (inputNum<= lowNum && inputNum!=-99){
                lowNum=inputNum;
        };    
        
    }
    //Map inputs -> outputs
    
 
    //Display the outputs
    cout<<"Smallest number in the series is"<<" "<<lowNum<<endl;
    cout<<"Largest  number in the series is"<<" "<<upperNum;

    //Exit stage right or left!
    return 0;
}
