/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 9:49 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

     //Set the random number seed
    
    //Declare Variables
    int MRC;
    int NOP;
    int TMP;
    int NEP;
    
    //Initialize or input i.e. set variable values
    
    cout<<"Input the maximum room capacity and the number of people"<<endl;
    cin>>MRC>>NOP;
    
    //Map inputs -> outputs
    
    TMP=NOP-MRC;
    NEP=MRC-NOP;
    
    //Display the outputs

    if (NOP>MRC) {
        cout<<"Meeting cannot be held."<<endl;
        cout<<"Reduce number of people by"<<" "<<TMP<<" "<<"to avoid fire violation.";
    }
    else {
        cout<<"Meeting can be held."<<endl;
        cout<<"Increase number of people by"<<" "<<NEP<<" "<<"will be allowed without violation.";
    }
    
    //Exit stage right or left!
    
    return 0;
}

