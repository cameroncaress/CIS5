/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 9:29 AM
 */

#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <cmath>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    //Set the random number seed
    
    //Declare Variables
    float sineVal;
    float cosineVal; 
    float tangentVal;
    float angleDegree;
    float piVal=3.1415926;
    
    //Initialize or input i.e. set variable values
    cout<<"Calculate trig functions"<<endl;
    cout<<"Input the angle in degrees."<<endl;
    cin>>angleDegree;
    
    //Map inputs -> outputs

    sineVal=sin(angleDegree*piVal/180);
    cosineVal=cos(angleDegree*piVal/180);
    tangentVal=tan(angleDegree*piVal/180);
    
    
    //Display the outputs
    cout<<"sin"<<"("<<angleDegree<<")"<<" "<<"="<<" "<<fixed<<setprecision(4)<<sineVal<<endl;
    cout<<"cos"<<"("<<fixed<<setprecision(0)<<angleDegree<<")"<<" "<<"="<<" "<<fixed<<setprecision(4)<<cosineVal<<endl;
    cout<<"tan"<<"("<<fixed<<setprecision(0)<<angleDegree<<")"<<" "<<"="<<" "<<fixed<<setprecision(4)<<tangentVal;
    
    //Exit stage right or left!
    
    return 0;
}

