/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 25, 2022, 6:12 PM
 */

#include <iostream>  //Input/Output Library
#include <cstdlib>   //Random Functions
#include <ctime>     //Time Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
void fillAry(int a[],int SIZE){
    for(int i=0;i<SIZE;i++){
        cin>>a[i];
    }
};
int prntAry(int a[],int SIZE){
    int check;
    for (int i=0;i<SIZE;i++){
        check=(i)%10;
        if(check==0&&i!=0){
            cout<<endl;
        }
        cout<<a[i]<<" ";
    }
};

void selSrt(int a[],int SIZE){
    int i, j, small, temp;
    for(i=0;i<SIZE-1;i++){
        small=i;
        for(j=i+1;j<SIZE;j++){
            if(a[j]<a[small]){
                small=j;
            }
        }
        temp=a[i];
        a[i]=a[small];
        a[small]=temp;
    }
    
};

int binSrch(int a[],int SIZE,int val){
  int start=0,mid,end=SIZE-1;
  while(start<=end){
      mid=(start+end)/2;
      if(a[mid]==val){
          return mid;
      }else if(val>a[mid]){
          start=mid+1;
      }else if(val<a[mid]){
          end=mid-1;
      }
  }
  return -1;  
};

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    const int SIZE=100;
    int array[SIZE];
    int indx=0,val;
    
    //Initialize or input i.e. set variable values
    fillAry(array,SIZE);
    cin>>val;

    //Sorted List
    selSrt(array,SIZE);
    //Display the outputs
    prntAry(array,SIZE);
    cout<<endl<<endl;
    indx=binSrch(array,SIZE,val);
    cout<<"Input the value to find in the array"<<endl;
    if(indx>=0){
        cout<<val<<" was found at indx = "<<indx<<endl;
    }else if(indx==-1){
        cout<<val<<"was not found in array"<<endl;
    }
    //Exit stage right or left!
    return 0;
}
