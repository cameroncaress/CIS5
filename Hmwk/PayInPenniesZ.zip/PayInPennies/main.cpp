/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 14, 2022, 3:39 PM
 */

#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int days;
    int payDay=1;
    int paySum;
                 
    //Initialize or input i.e. set variable values
    cin>>days;
    payDay=1;
    paySum=payDay;
    
    
    
    //Map inputs -> outputs
    for (int day=2; day<=days;day++){
        payDay*=2;
        paySum+=payDay;
    }
    
    
    //Display the outputs
    int dollars=paySum/100;
    int pennies=paySum%100;
    cout<<"Pay = $"<<dollars<<"."<<(pennies<10?"0":"")<<pennies;
    
    
    
    //Exit stage right or left!
    return 0;
}
