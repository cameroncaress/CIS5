/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 9:50 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

     //Set the random number seed
    
    //Declare Variables
   
    int num1;
    int num2;
    int num3;
    int num4;
    int num5;
    int num6;
    int num7;
    int num8;
    int num9;
    int num10;
    int negSum=0;
    int posSum=0;
    int totSum=0;
    
    //Initialize or input i.e. set variable values
    
    cout<<"Input 10 numbers, any order, positive or negative"<<endl;
    cin>>num1>>num2>>num3>>num4>>num5>>num6>>num7>>num8>>num9>>num10;
    
    string result;
    result = num1>0? posSum+=num1:negSum+=num1;
    result = num2>0? posSum+=num2:negSum+=num2;
    result = num3>0? posSum+=num3:negSum+=num3;
    result = num4>0? posSum+=num4:negSum+=num4;
    result = num5>0? posSum+=num5:negSum+=num5;
    result = num6>0? posSum+=num6:negSum+=num6;
    result = num7>0? posSum+=num7:negSum+=num7;
    result = num8>0? posSum+=num8:negSum+=num8;
    result = num9>0? posSum+=num9:negSum+=num9;
    result = num10>0? posSum+=num10:negSum+=num10;

    
    //Map inputs -> outputs
    
    totSum=negSum+posSum;
    
    //Display the outputs
   
    cout<<"Negative sum"<<" "<<"="<<setw(4)<<negSum<<endl;
    cout<<"Positive sum"<<" "<<"="<<setw(4)<<posSum<<endl;
    cout<<"Total sum"<<"    "<<"="<<setw(4)<<totSum;
    
    //Exit stage right or left!
    
    return 0;
}

