/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 14, 2022, 3:50 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;

float findMax2(float first, float second){
    float largestNum;
    
    if (first>=second){
        largestNum=first;
    } else {
        largestNum=second;
    }
    return largestNum;
};

float findMax3(float first, float second, float third){
    float largestNum2;
    if (first>=second && first>=third){
        largestNum2=first;
    } else if (third>=first && third>=second){
        largestNum2=third;
    } else {
        largestNum2=second;
    }
    
    return largestNum2;
    
};



//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float first;
    float second;
    float third;
    float fun1;
    float fun2;
    float largestNumOf2;
    float largestNumOf3;
   
    //Initialize or input i.e. set variable values
    cout<<"Enter first number:"<<endl;
    cin>>first;
    cout<<endl;
    cout<<"Enter Second number:"<<endl;
    cin>>second;
    cout<<endl;
    cout<<"Enter third number:"<<endl;
    cin>>third;
    cout<<endl;
    
    largestNumOf2=findMax2(first, second);
    largestNumOf3=findMax3(first, second, third);
    
    cout<<"Largest number from two parameter function:"<<endl;
    cout<<largestNumOf2<<endl;
    cout<<endl;
    
    cout<<"Largest number from three parameter function:"<<endl;
    cout<<largestNumOf3<<endl;
    
    //Map inputs -> outputs
    
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}
