/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 25, 2022, 6:05 PM
 */

#include <iostream>  //Input/Output Library
#include <cstdlib>   //Srand
#include <ctime>     //Time to set random number seed
#include <cmath>     //Math Library
#include <iomanip>   //Format Library
using namespace std;
  
int main (){
    int arr[50], num=50, temp, i, j, cols, rows, check;
     
    for (i=0;i<num;i++){  
        cin>>arr[i];  
    }  
    for (i=0,j=num-1;i<num/2;i++,j--){   
        temp=arr[i];  
        arr[i]=arr[j];  
        arr[j]=temp;  
    }  
    // use for loop to print the reverse array  
    for (i=0;i<num;i++){
        check=(i)%10;
        if(check==0&&i!=0){
            cout<<endl;
        }
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    return 0;  
} 
