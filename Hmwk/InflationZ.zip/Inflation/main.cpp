/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 14, 2022, 3:47 PM
 */

#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
float calcInflation(float currentPrice, float pastPrice){
    float percInflation;
    
    percInflation=((currentPrice-pastPrice)/pastPrice)*100.00;
    
    return percInflation;
}



//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float currentPrice;
    float pastPrice;
    float infRate;
    string yORn="y";
    
    
    //Initialize or input i.e. set variable values
    while (yORn=="y") {
        cout<<"Enter current price:"<<endl;
        cin>>currentPrice;
        cout<<"Enter year-ago price:"<<endl;
        cin>>pastPrice;
        infRate=calcInflation(currentPrice, pastPrice);
        cout<<"Inflation rate:"<<" "<<fixed<<setprecision(2)<<infRate<<"%"<<endl;
        cout<<endl;
        cout<<"Again:"<<endl;

        cin>>yORn;
        if (yORn=="y"){
            cout<<endl;
        }
        
    }
    
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}
