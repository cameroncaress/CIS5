/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 14, 2022, 3:41 PM
 */

#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {

    int numSize;
    string letterType;
    
    cin>>numSize;
    cin>>letterType;
    
    for (int rows=1; rows <= numSize-1; rows++){
        for (int cols=1; cols<= numSize; cols++){
            cout<<letterType;
    
        }
          
        cout<<endl;
           
    }
    
    for (int rows=1; rows <= numSize-(numSize-1); rows++){
        for (int cols=1; cols<= numSize; cols++){
            cout<<letterType;
        }
    }
    return 0;
}
