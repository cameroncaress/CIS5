/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 25, 2022, 6:07 PM
 */

#include <iostream>  //Input/Output Library
#include <fstream>   //File I/O
#include <string.h>    //String Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string key,answers;
    float score=0,sum=0;
    int SIZE=20;
    char arrayKey[SIZE];
    char arrayAns[SIZE];
    
    
    //Initialize or input i.e. set variable values
    cin>>key;
    for(int i=0;i<SIZE;i++){
        cin>>arrayKey[i];
    }
    cin>>answers;
    for(int i=0;i<SIZE;i++){
        cin>>arrayAns[i];
    }

    //Score the exam
    cout<<"C/W     ";
    for(int i=0;i<SIZE;i++){
        if(arrayKey[i]==arrayAns[i]){
            cout<<"C"<<" ";
            sum++;
        }else{
            cout<<"W"<<" ";
        }
    }
    cout<<endl;
   //output the percent correct
    score=(sum/20)*100;
    cout<<"Percentage Correct ="<<" "<<score<<"%"<<endl;
    

    //Exit stage right or left!
    return 0;
}
