/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 9:21 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

        //Set the random number seed
    
    //Declare Variables
    float priceofproperty;
    float insuranceneeded;
    
    //Initialize or input i.e. set variable values
    cout<<"Insurance Calculator"<<endl;
    cout<<"How much is your house worth?"<<endl;
    cin>>priceofproperty;
    
    //Map inputs -> outputs
    insuranceneeded=priceofproperty*0.80;
    //Display the outputs
    cout<<"You need $"<<insuranceneeded<<" "<<"of insurance.";
    
    //Exit stage right or left!
    
    return 0;
}

