/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 9:47 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    //Set the random number seed
    
    //Declare Variables
    float PAS;
    float rtroPay;
    float NAS;
    float NMS;
    
    
    
    //Initialize or input i.e. set variable values
    cout<<"Input previous annual salary."<<endl;
    cin>>PAS;
    
    
    //Map inputs -> outputs
 
    rtroPay=0.076*PAS/2;
    NAS=PAS*0.076+PAS;
    NMS=NAS/12.0;
    
    //Display the outputs
    
    cout<<"Retroactive pay"<<"    "<<"="<<" "<<"$"<<setw(7)<<fixed<<setprecision(2)<<rtroPay<<endl;
    cout<<"New annual salary"<<"  "<<"="<<" "<<"$"<<setw(7)<<fixed<<setprecision(2)<<NAS<<endl;
    cout<<"New monthly salary"<<" "<<"="<<" "<<"$"<<setw(7)<<fixed<<setprecision(2)<<NMS;

    
    //Exit stage right or left!
    
    return 0;
}

