/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 7, 2022, 10:04 AM
 */

#include <cstdlib>
#include <iomanip>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

     //Set random number seed here when needed
    
    //Declare variables or constants here
    //7 characters or less
  
  float exciTax=0.39;
  float saleTax=0.08;
  float capFee=0.10;
  float fedExci=0.184;
  float oilProf=0.065;
  float cstPGAL;
  float taxPGAL;
  float percGal;
  float prfPGAL;
  float percPrf;
  
  cout<<"This program calculates the percentage gas tax on a gallon of gas, and the profit made from a given gallon of gas."<<endl;
  cout<<"How much do you pay per gallon of gas?"<<endl;
  cin>>cstPGAL;
  
  taxPGAL=(exciTax)+(cstPGAL*saleTax)+(capFee)+(fedExci);
  
  percGal=taxPGAL/cstPGAL*100.0;
  
  prfPGAL=cstPGAL-taxPGAL;
  
  percPrf=prfPGAL/cstPGAL*100.0;
  
  cout<<"The percentage gas tax on a gallon of gas is"<<" "<<percGal<<"."<<endl;
  cout<<"The percent profit made from a gallon of gas is"<<" "<<percPrf<<"."<<endl;    
    
    //Exit stage left
    
    return 0;
}

