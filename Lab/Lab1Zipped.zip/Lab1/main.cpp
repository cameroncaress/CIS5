/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Cameron Caress
 *
 * Created on June 30, 2022, 8:02 PM
 */

#include <iostream>
using namespace std;

int main()
{
    float percFull; //percentage of gas in the tank
    float tankSize; //amount of gallons gas tank holds
    float galRequired; //gallons needed to fill the gas tank
    
    //get percentage full
    cout<<"What percentage of gas is in the tank?"<<endl;
    cin>>percFull;

    //get total size of tank
    cout<<"How many gallons does the gas tank hold?"<<endl;
    cin>>tankSize;
    
    //calculate gallons needed
    galRequired=tankSize*(1-(percFull/100.0));
    cout<<"Gallons Required to fill up="<<galRequired<<endl;
    
    //calculate the cost of gas station 1
    float gasperGal; //regular gas $/gallon
    float milesToandFromstation; //distance to gas station
    float costTofill; //amount of money needed to fill tank
    float costToDrive; //cost to and from gas station
    float MPG; //miles/gallon
    float mileageCost; //cost to gas station with mileage
    float newPPG; //new price per gallon
    
    //get price per gallon
    cout<<"How much is gas per gallon?"<<endl;
    cin>>gasperGal;
            
    costTofill=gasperGal*galRequired;
    cout<<"The cost to fill your tank is"<<costTofill<<endl;
    
    //get distance
    cout<<"How many miles to and from the gas station?"<<endl;
    cin>>milesToandFromstation;
    
    //get mpg
    cout<<"How many mpg does your the car get?"<<endl;
    cin>>MPG;
    
    //calculate how much to and from gas station
    costToDrive=(milesToandFromstation/MPG)*gasperGal;
    cout<<"The cost to drive to and from the gas station is"<<costToDrive<<endl;
    
    mileageCost=costToDrive+costTofill;
    cout<<"The cost to drive to and from the gas station with mileage is"<<mileageCost<<endl;
    
    newPPG=(mileageCost/galRequired);
    cout<<"The total cost per gallon when taking mileage into account is"<<newPPG<<endl;
    
    //calculate cost to gas station 2
    float regularGaspergal;
    float completeTotalDistance;
    float costTofillup;
    float costtodrivedistance;
    float totalcostwithmileagetostation;
    float newestPPG;
    
    cout<<"What is the regular price of gas per gallon?"<<endl;
    cin>>regularGaspergal;
            
    cout<<"What is the complete total distance driven back and forth?"<<endl;
    cin>>completeTotalDistance;
            
    costTofillup=regularGaspergal*galRequired;
    cout<<"The cost to fill up is"<<costTofillup<<endl;
    
    costtodrivedistance=regularGaspergal*(milesToandFromstation/MPG);
    cout<<"The cost to drive the distance there and back from the gas station is"<<costtodrivedistance<<endl;
    
    totalcostwithmileagetostation=costTofillup+costtodrivedistance;
    cout<<"The total cost with mileage to gas station is"<<totalcostwithmileagetostation<<endl;
    
    newestPPG=totalcostwithmileagetostation/galRequired;
    cout<<"The new price per gallon when taking into account the mileage is"<<newestPPG<<endl;
    
    cin>>gasperGal;
    
    return 0; 
    
}

