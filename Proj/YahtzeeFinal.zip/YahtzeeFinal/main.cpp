/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */
/*
 * File:   main.cpp
 * Author: Cameron Caress
 *
 * Created on July 29, 2022, 9:07 AM
 */
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
#include <cstring>
using namespace std;
/*
 * 
 */

//functions go here
int dieRoll(){
    int dieVal;
    int die1[6]={1,6,5,4,2,3};
    
    srand(time(0));
    for(int i=1;i<2;i++){
            dieVal=rand()%6;
        }
    dieVal=die1[dieVal];
    return dieVal;
};
string diceValueSum(int dieVal){
    string valueName;
    switch(dieVal){
        case 1: cout<<" -------"<<endl;
               cout<<"|       |"<<endl;
               cout<<"|   *   |"<<endl;
               cout<<"|       |"<<endl;
                cout<<" -------"<<endl;
        
        break;
        case 2: cout<<" -------"<<endl;
               cout<<"| *     |"<<endl;
               cout<<"|       |"<<endl;
               cout<<"|     * |"<<endl;
                cout<<" -------"<<endl;
        break;
        case 3: cout<<" -------"<<endl;
               cout<<"| *     |"<<endl;
               cout<<"|   *   |"<<endl;
               cout<<"|     * |"<<endl;
                cout<<" -------"<<endl;
        break;
        case 4: cout<<" -------"<<endl;
               cout<<"| *   * |"<<endl;
               cout<<"|       |"<<endl;
               cout<<"| *   * |"<<endl;
                cout<<" -------"<<endl;
        break;
        case 5: cout<<" -------"<<endl;
               cout<<"| *   * |"<<endl;
               cout<<"|   *   |"<<endl;
               cout<<"| *   * |"<<endl;
                cout<<" -------"<<endl;
        break;
        case 6: cout<<" -------"<<endl;
               cout<<"| *   * |"<<endl;
               cout<<"| *   * |"<<endl;
               cout<<"| *   * |"<<endl;
                cout<<" -------"<<endl;
        break;
    }
    return valueName;
};

int main(int argc, char** argv) {
    //declare necessary variables
    int yourRoll=0,dieVal=0,valueName=0,i=0,upperSec=0,lowerSec=0,reRoll=0,round=0;
    int totalScore=0,smStraightCheck=0,totalCheck,oneCheck=0,twoCheck=0,threeCheck=0,fourCheck=0,fiveCheck=0,sixCheck=0;
    int lgStraightCheck=0,fullHouseCheck=0,threeKindCheck=0,fourKindCheck=0,chanceCheck=0;
    int one=0,two=0,three=0,four=0,five=0,six=0,threeKind=0,fourKind=0,fullHouse=0,smStraight=0,lgStraight=0,yahtzee=0,chance=0;
    int bonus=0,points=0,scoredOne=0,scoredTwo=0,scoredThree=0,scoredFour=0,scoredFive=0,scoredSix=0,yahtzeeCheck=0;
    int playerDice[5]={1,2,3,4,5},diceToReRoll;
    char yn='y',rollAgain[5];
    int scoreChoice=0;
    
    cout<<"Press Enter To Play Yahtzee"<<endl;
    
    while(round<13){
        round++;
        reRoll=0;
        yn='y';
        totalCheck=0;
        points=0;
        
        cin.ignore();
        for(int i=0;i<5;i++){
            cout<<"Press enter to roll die "<<i+1<<"/5"<<endl;
            cin.get();
            playerDice[i]=dieRoll();
            yourRoll+=playerDice[i];
                if(playerDice[i]==1){
                    one+=1;
                }else if(playerDice[i]==2){
                    two+=2;
                }else if(playerDice[i]==3){
                    three+=3;
                }else if(playerDice[i]==4){
                    four+=4;
                }else if(playerDice[i]==5){
                    five+=5;
                }else if(playerDice[i]==6){
                    six+=6;
                }
            cout<<diceValueSum(playerDice[i])<<endl;
            cout<<endl;
        }
        
        cout<<"Currently, you have:"<<endl;
        cout<<endl;
        cout<<diceValueSum(playerDice[4])<<diceValueSum(playerDice[3])<<diceValueSum(playerDice[2])<<diceValueSum(playerDice[1])<<diceValueSum(playerDice[0])<<endl;

        while( (reRoll<2) && (yn=='y'||yn=='Y') ){
            cout<<"Re-roll any die?"<<endl;
            cin>>yn;
            reRoll++;
            if(yn=='y'||yn=='Y'){
                cout<<"What di(c)e do you want to re-roll? (enter 123, 245, i.e.)"<<endl;
                cin>>rollAgain;
                cout<<endl;

                //loop through all the dice to re-roll
                for(int i=0;i<strlen(rollAgain);i++){
                    
                    //get the dice number to re-roll
                    diceToReRoll = rollAgain[i]-49;
                    if(diceToReRoll>=0&&diceToReRoll<=4){
                        cout<<"Press enter to re-roll die "<<diceToReRoll+1<<endl;
                        cin.get();
                        yourRoll-=playerDice[diceToReRoll];
                        playerDice[diceToReRoll] = dieRoll();
                        cout<<diceValueSum(playerDice[diceToReRoll])<<endl;
                        cout<<endl;
                            if(playerDice[diceToReRoll]==1){
                                one+=1;
                            }else if(playerDice[diceToReRoll]==2){
                                two+=2;
                            }else if(playerDice[diceToReRoll]==3){
                                three+=3;
                            }else if(playerDice[diceToReRoll]==4){
                                four+=4;
                            }else if(playerDice[diceToReRoll]==5){
                                five+=5;
                            }else if(playerDice[diceToReRoll]==6){
                                six+=6;
                            }
                        yourRoll+=playerDice[diceToReRoll];
                        cout<<endl;
                    }else{
                        cout<<"Die value is out of range"<<endl;
                    }
                }

            }else if(yn=='n'||yn=='N'){
            
            }else if(reRoll==2){
                yn='n';
            }
        }
        cout<<"Currently, you have:"<<endl;
        cout<<endl;
        cout<<diceValueSum(playerDice[4])<<diceValueSum(playerDice[3])<<diceValueSum(playerDice[2])<<diceValueSum(playerDice[1])<<diceValueSum(playerDice[0])<<endl;
        
        cout<<"What would you like to score?"<<endl;
        cout<<"1=ones"<<endl;
        cout<<"2=twos"<<endl;
        cout<<"3=threes"<<endl;
        cout<<"4=fours"<<endl;
        cout<<"5=fives"<<endl;
        cout<<"6=sixes"<<endl;
        cout<<"7=three of a kind"<<endl;
        cout<<"8=four of a kind"<<endl;
        cout<<"9=full house"<<endl;
        cout<<"10=small straight"<<endl;
        cout<<"11=large straight"<<endl;
        cout<<"12=yahtzee"<<endl;
        cout<<"13=chance"<<endl;
        cout<<endl;
        cout<<"Scoring choice: ";
        cin>>scoreChoice;
        
        if(oneCheck==1&&scoreChoice==1){
            cout<<"Cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(twoCheck==1&&scoreChoice==2){
            cout<<"Cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice; 
        }else if(threeCheck==1&&scoreChoice==3){
            cout<<"Cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(fourCheck==1&&scoreChoice==4){
            cout<<"Cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(fiveCheck==1&&scoreChoice==5){
            cout<<"Cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(sixCheck==1&&scoreChoice==6){
            cout<<"Cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(smStraightCheck==1&&scoreChoice==10){
            cout<<"Cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
       }else if(yahtzeeCheck==1&&scoreChoice==12){
            cout<<"cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(lgStraightCheck==1&&scoreChoice==11){
            cout<<"cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(chanceCheck==1&&scoreChoice==13){
            cout<<"cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(fullHouseCheck==1&&scoreChoice==9){
            cout<<"cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(threeKindCheck==1&&scoreChoice==7){
            cout<<"cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }else if(fourKindCheck==1&&scoreChoice==8){
            cout<<"cant score one value more than one time"<<endl;
            cout<<"Try again"<<endl;
            cin>>scoreChoice;
        }
        
                yourRoll=0;
                if((oneCheck<1)&&scoreChoice==1){
                    scoredOne=one;
                    two=0;
                    three=0;
                    four=0;
                    five=0;
                    six=0;
                    yahtzee=0;
                    oneCheck++;
                    yourRoll+=one;
                }else if((twoCheck<1)&&scoreChoice==2){
                    one=0;
                    scoredTwo=two;
                    three=0;
                    four=0;
                    five=0;
                    six=0;
                    yahtzee=0;
                    twoCheck++;
                    yourRoll+=two;
                 }else if((threeCheck<1)&&scoreChoice==3){
                    one=0;
                    two=0;
                    scoredThree=three;
                    four=0;
                    five=0;
                    six=0;
                    yahtzee=0;
                    threeCheck++;
                    yourRoll+=three;
                }else if((fourCheck<1)&&scoreChoice==4){
                    one=0;
                    two=0;
                    three=0;
                    scoredFour=four;
                    five=0;
                    six=0;
                    yahtzee=0;
                    fourCheck++;
                    yourRoll+=four;
                }else if((fiveCheck<1)&&scoreChoice==5){
                    one=0;
                    two=0;
                    three=0;
                    four=0;
                    scoredFive=five;
                    six=0;
                    yahtzee=0;
                    fiveCheck++;
                    yourRoll+=five;
                }else if((sixCheck<1)&&scoreChoice==6){
                    one=0;
                    two=0;
                    three=0;
                    four=0;
                    five=0;
                    yahtzee=0;
                    scoredSix=six;
                    sixCheck++;
                    yourRoll+=six;
                }else if((yahtzeeCheck<1)&&scoreChoice==12){
                    yahtzeeCheck++;
                    
                    yahtzee=50;
                    yourRoll+=yahtzee;
                }else if((chanceCheck<1)&&scoreChoice==13){
                    cout<<"How many points?"<<endl;
                    cin>>points;
                    chanceCheck++;
                    chance=points;
                    yourRoll+=chance;
                }else if((threeKindCheck<1)&&scoreChoice==7){
                    cout<<"How many points?"<<endl;
                    cin>>points;
                    threeKindCheck++;
                    threeKind=points;
                    yourRoll+=threeKind;
                }else if((fourKindCheck<1)&&scoreChoice==8){
                    cout<<"How many points?"<<endl;
                    cin>>points;
                    fourKindCheck++;
                    fourKind=points;
                    yourRoll+=fourKind;
                }else if((fullHouseCheck<1)&&scoreChoice==9){
                    fullHouseCheck++;
                    fullHouse=25;
                    yourRoll+=fullHouse;
                }else if((lgStraightCheck<1)&&scoreChoice==11){
                    lgStraightCheck++;
                    lgStraight=40;
                    yourRoll+=lgStraight;
                }else if((smStraightCheck<1)&&scoreChoice==10){
                    smStraightCheck++;
                    smStraight=30;
                    yourRoll+=smStraight;
                }
                
        upperSec=scoredOne+scoredTwo+scoredThree+scoredFour+scoredFive+scoredSix;
        if(upperSec>=63){
            cout<<"Upper Section Bonus +35"<<endl;
            bonus+=35;
        }
        
        totalScore+=yourRoll;
     
        cout<<" ----------SCORECARD---------- "<<endl;
        cout<<"| Upper Section               |"<<endl;
        cout<<"| Ones="<<setw(2)<<setfill('0')<<scoredOne<<"                     |"<<endl;
        cout<<"| Twos="<<setw(2)<<setfill('0')<<scoredTwo<<"                     |"<<endl;
        cout<<"| Threes="<<setw(2)<<setfill('0')<<scoredThree<<"                   |"<<endl;
        cout<<"| Fours="<<setw(2)<<setfill('0')<<scoredFour<<"                    |"<<endl;
        cout<<"| Fives="<<setw(2)<<setfill('0')<<scoredFive<<"                    |"<<endl;
        cout<<"| Sixes="<<setw(2)<<setfill('0')<<scoredSix<<"                    |"<<endl;
        cout<<"| Upper Section Bonus="<<setw(2)<<setfill('0')<<bonus<<"      |"<<endl;
        cout<<"|                             |"<<endl;
        cout<<"| LowerSection                |"<<endl;
        cout<<"| Three of a Kind="<<setw(2)<<setfill('0')<<threeKind<<"          |"<<endl;
        cout<<"| Four of a Kind="<<setw(2)<<setfill('0')<<fourKind<<"           |"<<endl;
        cout<<"| Full House="<<setw(2)<<setfill('0')<<fullHouse<<"               |"<<endl;
        cout<<"| Small Straight="<<setw(2)<<setfill('0')<<smStraight<<"           |"<<endl;
        cout<<"| Large Straight="<<setw(2)<<setfill('0')<<lgStraight<<"           |"<<endl;
        cout<<"| Yahtzee="<<setw(2)<<setfill('0')<<yahtzee<<"                  |"<<endl;
        cout<<"| Chance="<<setw(2)<<setfill('0')<<chance<<"                   |"<<endl;
        cout<<"|-----------------------------|"<<endl;
        cout<<"| Total Score="<<setw(2)<<setfill('0')<<totalScore<<"              |"<<endl;
        cout<<" ----------------------------- "<<endl;
        cout<<endl;
        cout<<"Next Turn"<<endl;
        cout<<endl;
    }
    cout<<"Game over"<<endl;
    return 0;
}


