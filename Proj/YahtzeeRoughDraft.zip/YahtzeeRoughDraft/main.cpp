/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */
/* 
 * File:   main.cpp
 * Author: Cameron Caress
 *
 * Created on July 29, 2022, 9:07 AM
 */
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;
/*
 * 
 */

//functions go here
string diceValue(int dieVal){
    string valueName;
    switch(dieVal){
        case 1: cout<<" -------"<<endl;
               cout<<"|       |"<<endl;
               cout<<"|   *   |"<<endl;
               cout<<"|       |"<<endl;
                cout<<" -------"<<endl;
                valueName="one";
        
        break;
        case 2: cout<<" -------"<<endl;
               cout<<"| *     |"<<endl;
               cout<<"|       |"<<endl;
               cout<<"|     * |"<<endl;
                cout<<" -------"<<endl;
                valueName="two";
        break;
        case 3: cout<<" -------"<<endl;
               cout<<"| *     |"<<endl;
               cout<<"|   *   |"<<endl;
               cout<<"|     * |"<<endl;
                cout<<" -------"<<endl;
                valueName="three";
        break;
        case 4: cout<<" -------"<<endl;
               cout<<"| *   * |"<<endl;
               cout<<"|       |"<<endl;
               cout<<"| *   * |"<<endl;
                cout<<" -------"<<endl;
                valueName="four";
        break;
        case 5: cout<<" -------"<<endl;
               cout<<"| *   * |"<<endl;
               cout<<"|   *   |"<<endl;
               cout<<"| *   * |"<<endl;
                cout<<" -------"<<endl;
                valueName="five";
        break;
        case 6: cout<<" -------"<<endl;
               cout<<"| *   * |"<<endl;
               cout<<"| *   * |"<<endl;
               cout<<"| *   * |"<<endl;
                cout<<" -------"<<endl;
                valueName="six";
        break;
    }
    return valueName;
};
int dieRoll(){
    int dieVal;
    int die1[6]={1,6,5,4,2,3};
    
    srand(time(0));
    for(int i=1;i<2;i++){
            dieVal=rand()%6;
        }
    dieVal=die1[dieVal];
    return dieVal;
};

int main(int argc, char** argv) {
    //declare necessary variables
    int yourRoll=0,dieVal=0,valueName=0,i=0,upperSec=0,lowerSec=0,reRoll=0,round=0;
    int totalScore=0,smStraightCheck=0,totalCheck,oneCheck=0,twoCheck=0,threeCheck=0,fourCheck=0,fiveCheck=0,sixCheck=0,one=0,two=0,three=0,four=0,five=0,six=0,threeKind=0,fourKind=0,fullHouse=0,smStraight=0,lgStraight=0,yahtzee=0,chance=0,bonus=0,scoredOne=0,scoredTwo=0,scoredThree=0,scoredFour=0,scoredFive=0,scoredSix=0;
    int playerDice[5]={1,2,3,4,5};
    char yn='y';
    string scoreChoice="Perry";
    
    cout<<"Press Enter To Play Yahtzee"<<endl;
    
    while(round<13){
        round++;
        reRoll=0;
        yn='y';
        totalCheck=0;
        
        cin.ignore();
        for(int i=0;i<5;i++){
            cout<<"Press enter to roll die "<<i+1<<"/5"<<endl;
            cin.get();
            playerDice[i]=dieRoll();
            yourRoll+=playerDice[i];
                if(playerDice[i]==1){
                    one+=1;
                }else if(playerDice[i]==2){
                    two+=2;
                }else if(playerDice[i]==3){
                    three+=3;
                }else if(playerDice[i]==4){
                    four+=4;
                }else if(playerDice[i]==5){
                    five+=5;
                }else if(playerDice[i]==6){
                    six+=6;
                }
            cout<<"You rolled a "<<diceValue(playerDice[i])<<endl;
            cout<<endl;
        }

        while((reRoll<2)&&yn=='y'||yn=='Y'){
            cout<<"Re-roll any die?"<<endl;
            cin>>yn;
            reRoll++;
            if(yn=='y'||yn=='Y'){
                cout<<"Re-roll which die? i/5"<<endl;
                cin>>i;
                while(i<1||i>6){
                    cout<<"Number out of range"<<endl;
                    cout<<"Re-roll which die? i/5"<<endl;
                    cin>>i;
                }
                i-=1;
                cout<<endl;
                yourRoll-=playerDice[i];
                playerDice[i]=dieRoll();
                if(playerDice[i]==1){
                    one+=1;
                }else if(playerDice[i]==2){
                    two+=2;
                }else if(playerDice[i]==3){
                    three+=3;
                }else if(playerDice[i]==4){
                    four+=4;
                }else if(playerDice[i]==5){
                    five+=5;
                }else if(playerDice[i]==6){
                    six+=6;
                }
                yourRoll+=playerDice[i];
                cout<<"You rolled a "<<diceValue(playerDice[i])<<endl;
                cout<<endl;
            }else if(yn=='n'||yn=='N'){
            
            }else if(reRoll==2){
                yn='n';
            }
        }

                cout<<"What would you like to score? ones, twos, threes, small straight, large straight etc..."<<endl;
                cin>>scoreChoice;
                if(oneCheck==1&&scoreChoice=="ones"){
                    cout<<"Cant score one value more than one time"<<endl;
                    cout<<"Try again"<<endl;
                    cin>>scoreChoice;
                }else if(twoCheck==1&&scoreChoice=="twos"){
                    cout<<"Cant score one value more than one time"<<endl;
                    cout<<"Try again"<<endl;
                    cin>>scoreChoice; 
                }else if(threeCheck==1&&scoreChoice=="threes"){
                    cout<<"Cant score one value more than one time"<<endl;
                    cout<<"Try again"<<endl;
                    cin>>scoreChoice;
                }else if(fourCheck==1&&scoreChoice=="fours"){
                    cout<<"Cant score one value more than one time"<<endl;
                    cout<<"Try again"<<endl;
                    cin>>scoreChoice;
                }else if(fiveCheck==1&&scoreChoice=="fives"){
                    cout<<"Cant score one value more than one time"<<endl;
                    cout<<"Try again"<<endl;
                    cin>>scoreChoice;
                }else if(sixCheck==1&&scoreChoice=="sixes"){
                    cout<<"Cant score one value more than one time"<<endl;
                    cout<<"Try again"<<endl;
                    cin>>scoreChoice;
                }else if(smStraightCheck==1&&scoreChoice=="small straight"){
                    cout<<"Cant score one value more than one time"<<endl;
                    cout<<"Try again"<<endl;
                    cin>>scoreChoice;
                }
                yourRoll=0;
                if((oneCheck<1)&&scoreChoice=="ones"||scoreChoice=="Ones"){
                    scoredOne=one;
                    two=0;
                    three=0;
                    four=0;
                    five=0;
                    six=0;
                    oneCheck++;
                    yourRoll+=one;
                }else if((twoCheck<1)&&scoreChoice=="twos"||scoreChoice=="Twos"){
                    one=0;
                    scoredTwo=two;
                    three=0;
                    four=0;
                    five=0;
                    six=0;
                    twoCheck++;
                    yourRoll+=two;
                 }else if((threeCheck<1)&&scoreChoice=="threes"||scoreChoice=="Threes"){
                    one=0;
                    two=0;
                    scoredThree=three;
                    four=0;
                    five=0;
                    six=0;
                    threeCheck++;
                    yourRoll+=three;
                }else if((fourCheck<1)&&scoreChoice=="fours"||scoreChoice=="Fours"){
                    one=0;
                    two=0;
                    three=0;
                    scoredFour=four;
                    five=0;
                    six=0;
                    fourCheck++;
                    yourRoll+=four;
                }else if((fiveCheck<1)&&scoreChoice=="fives"||scoreChoice=="Fives"){
                    one=0;
                    two=0;
                    three=0;
                    four=0;
                    scoredFive=five;
                    six=0;
                    fiveCheck++;
                    yourRoll+=five;
                }else if((sixCheck<1)&&scoreChoice=="sixes"||scoreChoice=="Sixes"){
                    one=0;
                    two=0;
                    three=0;
                    four=0;
                    five=0;
                    scoredSix=six;
                    sixCheck++;
                    yourRoll+=six;
                }
                
        upperSec=one+two+three+four+five+six;
        if(upperSec>=63){
            cout<<"Upper Section Bonus +35"<<endl;
            bonus+=35;
        }
        totalScore+=yourRoll;
     
        cout<<" ----------SCORECARD---------- "<<endl;
        cout<<"| Upper Section               |"<<endl;
        cout<<"| Ones="<<setw(2)<<setfill('0')<<scoredOne<<"                     |"<<endl;
        cout<<"| Twos="<<setw(2)<<setfill('0')<<scoredTwo<<"                     |"<<endl;
        cout<<"| Threes="<<setw(2)<<setfill('0')<<scoredThree<<"                   |"<<endl;
        cout<<"| Fours="<<setw(2)<<setfill('0')<<scoredFour<<"                    |"<<endl;
        cout<<"| Fives="<<setw(2)<<setfill('0')<<scoredFive<<"                    |"<<endl;
        cout<<"| Sixes="<<setw(2)<<setfill('0')<<scoredSix<<"                    |"<<endl;
        cout<<"| Upper Section Bonus="<<setw(2)<<setfill('0')<<bonus<<"      |"<<endl;
        cout<<"|                             |"<<endl;
        cout<<"| LowerSection                |"<<endl;
        cout<<"| Three of a Kind="<<setw(2)<<setfill('0')<<threeKind<<"          |"<<endl;
        cout<<"| Four of a Kind="<<setw(2)<<setfill('0')<<fourKind<<"           |"<<endl;
        cout<<"| Full House="<<setw(2)<<setfill('0')<<fullHouse<<"               |"<<endl;
        cout<<"| Small Straight="<<setw(2)<<setfill('0')<<smStraight<<"           |"<<endl;
        cout<<"| Large Straight="<<setw(2)<<setfill('0')<<lgStraight<<"           |"<<endl;
        cout<<"| Yahtzee="<<setw(2)<<setfill('0')<<yahtzee<<"                  |"<<endl;
        cout<<"|-----------------------------|"<<endl;
        cout<<"| Total Score="<<setw(2)<<setfill('0')<<totalScore<<"              |"<<endl;
        cout<<" ----------------------------- "<<endl;
        cout<<endl;
        cout<<"Next Turn"<<endl;
        cout<<endl;
    }
    return 0;
}

