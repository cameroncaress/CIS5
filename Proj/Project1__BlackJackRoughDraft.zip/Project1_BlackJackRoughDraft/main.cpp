/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Spart
 *
 * Created on July 21, 2022, 9:30 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <ctime>
using namespace std;
/*
 * 
 */

//functions go under this line

//function to determine what number card you got
string cardNum(int cardVal){
    string CardNum;
    if(cardVal==1){
        CardNum="ace";
    }else if(cardVal==2){
        CardNum="two";
    }else if(cardVal==3){
        CardNum="three";
    }else if(cardVal==4){
        CardNum="four";
    }else if(cardVal==5){
        CardNum="five";
    }else if(cardVal==6){
        CardNum="six";
    }else if(cardVal==7){
        CardNum="seven";
    }else if(cardVal==8){
        CardNum="eight";
    }else if(cardVal==9){
        CardNum="nine";
    }else if(cardVal==10){
    }
    return CardNum;
};

//function determines what to do if you receive a card with value of ten
string JQK10(int cardVal){

};

//function to determine what suit your card is
string cardSuit(int i){
    string suitType[4]={"spades","diamonds","hearts","clubs"};
    int select;
    srand(time(0));
    for(i=1;i<2;i++){
        select=rand()%4;
    }
    return suitType[select];
};
    

int main(int argc, char** argv) {
    //declare variables
    char yn='y';
    int i, a, playerSum=0, dealerSum=0, cardVal, dealerWin, playerWin, bet=1, playerMoney=0;
    string hn="H", cardType, cardSuit, suitType;
    //card deck array
    int cardDeck[56]={2,4,3,10,10,8,7,6,1,10,7,8,5,10,4,9,6,5,3,8,7,1,5,9,10,10,2,7,1,4,10,10,3,2,6,10,10,4,8,6,5,1,10,9,9,3,10,2,10,10,10,10};
  
    cout<<"Playing Blackjack"<<endl;
    cout<<"Player starts with $500, you cannot bet more than you have and you cannot bet less than $25"<<endl;
    //while loop to keep playing
 while(yn=='y'||yn=='Y'){
     playerSum=0;
     dealerSum=0; 
     bet=0;
     playerMoney=500;

     
     
    while(bet<=24){
        //ask how much player wants to bet
        cout<<"How much do you want to bet?"<<endl;
        cout<<"$";
        cin>>bet;
        while(bet>playerMoney){
            cout<<"Bet cannot exceed your current funds"<<endl;
            cout<<"Try again"<<endl;
            cout<<"$";
            cin>>bet;
        }
        if(bet<=24){
            cout<<"Minimum buy in is $25"<<endl;
        }else{}
    }
     
     //show dealer's first card
    srand(time(0));
    for(i=1;i<2;i++){
            cardVal=rand()%52;
        }
    dealerSum+=cardDeck[cardVal];
    //naming the dealers sum for reference
    cout<<"Dealer received a(n)"<<" "<<cardNum(dealerSum)<<" of"<<" "<<endl;
    cout<<"Dealer's card is valued at"<<" "<<dealerSum<<" + unknown card"<<endl;
    cout<<endl;
    
    cin.ignore();
    cout<<"Press enter to receive your first card"<<endl;
    cin.get();
    srand(time(0));
    for(i=1;i<2;i++){
        cardVal=rand()%52;
    }
    
    //adding card value to player sum
    playerSum+=cardDeck[cardVal];
    cout<<"You have received a(n)"<<" "<<cardNum(cardVal)<<" of"<<" "<<suitType<<endl;
    cout<<"Your card is  valued at:"<<" "<<playerSum<<endl;
    cout<<endl;
 
    //randomly selecting player's second card
    cout<<"Press enter to receive your second card"<<endl;
    cin.get();
    cout<<endl;
    srand(time(0));
    for(i=1;i<2;i++){
        cardVal=rand()%52;
    }
        
        //adding card value to player sum
    playerSum+=cardDeck[cardVal];
    cout<<"You have received a(n)"<<" "<<cardNum(cardVal)<<" of"<<" "<<endl;
    cout<<"Your cards are valued at:"<<" "<<playerSum<<endl;
    cout<<endl;
    cout<<"Hit?(H/h) or Stay?(S/s)"<<endl;
    cin>>hn;
    cout<<endl;
        
    
    //player's turn to be dealt and play
    while((hn=="H"||hn=="h")&&playerSum<=21){
        //randomly selecting player's first card from the deck
        srand(time(0));
        for(i=1;i<2;i++){
            cardVal=rand()%52;
        }
        //naming the numbers to a playing card
        
        //adding card value to player sum
        playerSum+=cardDeck[cardVal];
        cout<<"You have received a(n)"<<" "<<cardNum(cardVal)<<" of"<<" "<<suitType<<endl;
        cout<<"Your cards are valued at:"<<" "<<playerSum<<endl;
        cout<<endl;
        
        //determining if player busted or not
        if(playerSum<=21){
            cout<<"Hit?(H/h) or Stay?(S/s)"<<endl;
            cin>>hn;
            cout<<endl;
        }else{
            cout<<"Player has busted, dealer wins!"<<endl;
            dealerWin=-1*bet;
            playerMoney+=dealerWin;
            cout<<"Your funds:"<<" "<<playerMoney<<endl;
            cout<<endl;
        }
    }
    
    //pick dealer's second card
    if(playerSum<=21){
        cout<<"Player's turn is done"<<endl;
        cout<<"Dealer's turn:"<<endl;
        while(dealerSum<=17){
            if(dealerSum<=21){
                srand(time(0));
                for(i=1;i<2;i++){
                    cardVal=rand()%52;
                }
                dealerSum+=cardDeck[cardVal];
                //naming the dealers sum for reference
                cout<<"Dealer received a(n)"<<" "<<cardNum(dealerSum)<<" of"<<" "<<endl;
                cout<<"Dealer's cards are valued at"<<" "<<dealerSum<<endl;
                cout<<endl;
            }
            
        }if(dealerSum>=22){
           cout<<"Dealer has busted, player wins!"<<endl;
            playerWin=bet;
            playerMoney+=playerWin;
            cout<<"Your funds:"<<" "<<playerMoney<<endl;
            cout<<endl;
        }
    }
    if(dealerSum<=21&&playerSum<=21){
        if(dealerSum>playerSum){
            cout<<"Dealer's cards are valued at:"<<" "<<dealerSum<<endl;
            cout<<"Player's cards are valued at:"<<" "<<playerSum<<endl;
            cout<<"Dealer wins!"<<endl;
            cout<<endl;
            dealerWin=-1*bet;
            playerMoney+=dealerWin;
            cout<<"Your funds:"<<" "<<playerMoney<<endl;
            cout<<endl;
        }else if(dealerSum<playerSum){
            cout<<"Dealer's cards are valued at:"<<" "<<dealerSum<<endl;
            cout<<"Player's cards are valued at:"<<" "<<playerSum<<endl;
            cout<<"Player wins!"<<endl;
            cout<<endl;
            playerWin=bet;
            playerMoney+=playerWin;
            cout<<"Your funds:"<<" "<<playerMoney<<endl;
            cout<<endl;
        }else if(dealerSum==playerSum){
            cout<<"Dealer's cards are valued at:"<<" "<<dealerSum<<endl;
            cout<<"Player's cards are valued at:"<<" "<<playerSum<<endl;
            cout<<"Draw!"<<endl;
            cout<<endl;
            playerMoney+=0;
            cout<<"Your funds:"<<" "<<playerMoney<<endl;
            cout<<endl;
        }
    }
cout<<"Do you want to play again?"<<endl;
if(playerMoney>0){
    cin>>yn;
    cout<<endl;
 }else if(playerMoney<=0){
     cout<<"You ran out of money"<<endl;
     cout<<"Game over"<<endl;
     yn='n';
 }
 }
    return 0;
}
